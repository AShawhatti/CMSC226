/*
 * Class: CMSC226
 * Instructor: Farnaz Eivazi
 * Description: Brief description of this file/module
 * Due: 9/21/2025
 * I pledge that I have completed the programming assignment independently. 
 * I have not copied the code from a student or any source.
 * I have not given my code to any student.
 * Print your Name here: Hassan Shawhatti
 */

#include <iostream>
using namespace std;
int main()
{
    //Book Info 
    cout << "Serendipity Booksellers\n";
    cout << "    Book Information\n";
    cout << "ISBN: \n";
    cout << "Title: \n";
    cout << "Author: \n";
    cout << "Publisher: \n";
    cout << "Date Added: \n";
    cout << "Quantity-On-Hand: \n";
    cout << "Wholesale Cost: \n";
    cout << "Retail Price: \n";
    return 0;
}