/*
 * Class: CMSC226
 * Instructor: Farnaz Eivazi
 * Description: Brief description of this file/module
 * Due: 9/21/2025
 * I pledge that I have completed the programming assignment independently. 
 * I have not copied the code from a student or any source.
 * I have not given my code to any student.
 * Print your Name here: Hassan Shawhatti
 */


#include <iostream>
using namespace std;
int main()
{
    //Input userchoice for ouput of where they want to go in main menu
    int Mainmenuchoice;
    cout << "Serendipity Booksellers" << endl;
    cout << "       Main Menu" << endl;
    cout << "1. Cashier Module" << endl;
    cout << "2. Inventory Database Module" << endl;
    cout << "3. Report Module" << endl;
    cout << "4. Exit" << endl;
    cout << " " << endl;
    cout << "Enter your Choice: \n";
    cin >> Mainmenuchoice;
    return 0;
}